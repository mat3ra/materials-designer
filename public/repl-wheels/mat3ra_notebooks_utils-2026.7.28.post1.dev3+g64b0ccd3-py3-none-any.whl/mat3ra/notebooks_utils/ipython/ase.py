from ase.atoms import Atoms
from ase.optimize import BFGS

from .plot._plotly import create_realtime_plot, create_update_callback


def run_ase_relaxation(
    atoms: Atoms,
    calculator,
    fmax: float = 0.05,
    title: str = "Real-time Optimization Progress",
    x_label: str = "Step",
    y_label: str = "Energy (eV)",
) -> Atoms:
    """
    Attach calculator, run BFGS relaxation, and stream a live energy-vs-step plot.

    Modifies atoms in place and also returns them for convenience.
    """
    atoms.set_calculator(calculator)
    dyn = BFGS(atoms)

    steps: list = []
    values: list = []
    figure = create_realtime_plot(title=title, x_label=x_label, y_label=y_label)
    callback = create_update_callback(
        dynamic_object=dyn,
        value_getter=atoms.get_total_energy,
        figure=figure,
        steps=steps,
        values=values,
        print_format="Step: {}, Energy: {:.4f} eV",
    )
    dyn.attach(callback, interval=1)
    dyn.run(fmax=fmax)
    return atoms
